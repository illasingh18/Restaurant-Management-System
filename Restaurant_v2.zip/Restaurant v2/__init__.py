from flask import Flask
from config import Config
from models import db

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Import Blueprints
from routes.home import home_bp
from routes.customers import customers_bp
from routes.employees import employees_bp
from routes.orders import orders_bp
from routes.inventory import inventory_bp
# from routes.menu import menu_bp


# Register Blueprints
app.register_blueprint(home_bp)
app.register_blueprint(customers_bp)
app.register_blueprint(employees_bp)
app.register_blueprint(orders_bp)
app.register_blueprint(inventory_bp)