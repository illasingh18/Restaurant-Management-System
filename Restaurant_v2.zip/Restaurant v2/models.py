import mysql.connector
from config import Config

# Establish database connection
db = mysql.connector.connect(
    host=Config.DB_HOST,
    user=Config.DB_USER,
    password=Config.DB_PASSWORD
)

cursor = db.cursor(dictionary=True)

# Create database if not exists
cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.DB_NAME}")
db.commit()
cursor.close()

# Reconnect to the specific database
db = mysql.connector.connect(
    host=Config.DB_HOST,
    user=Config.DB_USER,
    password=Config.DB_PASSWORD,
    database=Config.DB_NAME
)

cursor = db.cursor(dictionary=True)

# Creating tables

# employees_demo Table
cursor.execute("""                                  
    CREATE TABLE IF NOT EXISTS employees_demo (
        emp_id SMALLINT AUTO_INCREMENT PRIMARY KEY, 
        emp_name VARCHAR(100), 
        emp_role VARCHAR(50), 
        emp_salary DECIMAL(10,2),
        emp_phone INT,
        emp_address TEXT
    )
""")


# customers_demo Table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS customers_demo (
        cust_id SMALLINT AUTO_INCREMENT PRIMARY KEY, 
        cust_name VARCHAR(100), 
        cust_phone INT, 
        cust_address TEXT
    )
""")

# cursor.execute("""
#     CREATE TABLE IF NOT EXISTS orders (
#         order_id SMALLINT AUTO_INCREMENT PRIMARY KEY, 
#         customer_id SMALLINT, 
#         employee_id SMALLINT, 
#         total_price DECIMAL(10,2),
#         FOREIGN KEY (customer_id) REFERENCES customers(cust_id),
#         FOREIGN KEY (employee_id) REFERENCES employees(emp_id)
#     )
# """)

# inventory_demo Table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS inventory_demo (
        item_id SMALLINT AUTO_INCREMENT PRIMARY KEY, 
        item_name VARCHAR(100), 
        quantity INT, 
        unit VARCHAR(20)
    )
""")

# reservations Table
# cursor.execute("""
#     CREATE TABLE IF NOT EXISTS reservations (
#         reservation_id SMALLINT AUTO_INCREMENT PRIMARY KEY, 
#         customer_id SMALLINT, 
#         table_number SMALLINT, 
#         guests SMALLINT, 
#         reservation_date DATE,
#         reservation_time TIME,
#         FOREIGN KEY (customer_id) REFERENCES customers(cust_id)
#     )
# """)


db.commit()

# cursor.execute("SHOW TABLES")
# for x in cursor:
#     print(x)
# cursor.close()
