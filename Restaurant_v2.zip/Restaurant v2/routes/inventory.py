from flask import Blueprint, render_template, request
from models import cursor, db

# Creating a Blueprint
inventory_bp = Blueprint("inventory", __name__)

# Inventory Management
@inventory_bp.route('/inventory', methods=['GET', 'POST'])
def inventory_page():
    if request.method == 'POST':
        name = request.form['name']
        quantity = request.form['quantity']
        unit = request.form['unit']
        cursor.execute("INSERT INTO inventory_demo (item_name, quantity, unit) VALUES (%s, %s, %s)", (name, quantity, unit))
        db.commit()
    
    cursor.execute("SELECT * FROM inventory_demo")
    inventory = cursor.fetchall()
    return render_template("inventory.html", inventory=inventory)

@inventory_bp.route('/inventory_list')
def view_inventory():
    cursor.execute("SELECT * FROM inventory_demo")
    stocks = cursor.fetchall()
    return render_template("inventory_list.html", stocks=stocks)