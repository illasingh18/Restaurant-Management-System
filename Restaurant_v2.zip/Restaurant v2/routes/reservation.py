# from flask import Blueprint, request, render_template
# from models import cursor, db

# reservation_bp = Blueprint("reservation", __name__)

# # Table Reservation
# @reservation_bp.route('/reserve_table', methods=["GET","POST"])
# def reservation_page(): 
#     if request.method == 'POST':
#         customer_id=int(request.form.get('customer_id'))
#         table_number=int(request.form.get('table_number'))
#         guests=int(request.form.get('number_of_guests'))
#         date=request.form.get('date')
#         time=request.form.get('time')
        
#         if customer_id in cursor:
#             reserved_tables[id] = {"Name": customer_id, "Number_guests": number_of_guests, "Date": date, "Time": time, "Table_number": table_number}
#         else:
#             return "Customer not registered"
#     return render_template("reservation.html", reserved_tables=reserved_tables)