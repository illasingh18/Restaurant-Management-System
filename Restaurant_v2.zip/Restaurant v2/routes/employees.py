from flask import Blueprint, render_template, request
from models import cursor, db

# Creating a Blueprint
employees_bp = Blueprint("employees", __name__)

@employees_bp.route('/employees', methods=['GET', 'POST'])
def employee_page():
    if request.method == 'POST':
        name = request.form['name']
        role = request.form['role']
        salary = request.form['salary']
        phone = request.form['phone']
        address = request.form['address']
        cursor.execute("INSERT INTO employees_demo (emp_name, emp_role, emp_salary, emp_phone, emp_address) VALUES (%s, %s, %s, %s, %s)", (name, role, salary, phone, address))
        db.commit()

    cursor.execute("SELECT * FROM employees_demo")
    employees = cursor.fetchall()
    return render_template("employee.html", employees=employees)


@employees_bp.route('/employee_list')
def show_reg_employees():
    cursor.execute("SELECT * FROM employees_demo")
    reg_employees = cursor.fetchall()
    return render_template("employee_list.html", reg_employees=reg_employees)


