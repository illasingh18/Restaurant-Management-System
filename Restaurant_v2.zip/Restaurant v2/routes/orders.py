from flask import Blueprint, render_template, request
from models import cursor, db

# Creating a Blueprint
orders_bp = Blueprint("orders", __name__)

@orders_bp.route('/orders', methods=['GET', 'POST'])
def order_page():
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        total_price = request.form['total_price']
        cursor.execute("INSERT INTO orders (customer_id, total_price) VALUES (%s, %s)", (customer_id, total_price))
        db.commit()

    cursor.execute("SELECT * FROM orders")
    orders = cursor.fetchall()
    return render_template("orders.html", orders=orders)


# Order Management
# @app.route('/orders', methods=['GET', 'POST'])
# def order_page():
#     order_summary = []
#     selected_items = request.form.getlist('order_items')  # Get checked items
#     total_bill = 0  # Store total price

#     employee_id = request.form.get('Employee_ID')
#     customer_id = request.form.get('Customer_ID')

#     if not selected_items:
#         return render_template('orders.html', order_summary=[], total_bill=0)
#     else:
#         for item in selected_items:
#             quantity = int(request.form.get(f'quantity_{item}', 1))
#             price = float(request.form.get(f'price_{item}', 0.0))

#             cost = quantity * price
#             total_bill += cost

#             order_summary.append({"Emp_ID": employee_id, "Customer_ID": customer_id, "Item": item, "Quantity": quantity, "Price": price, "Cost": cost})

#     return render_template('orders.html', order_summary=order_summary, total_bill=total_bill, employee_id=employee_id, customer_id=customer_id)