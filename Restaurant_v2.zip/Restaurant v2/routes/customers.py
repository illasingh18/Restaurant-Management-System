from flask import Blueprint, render_template, request
from models import cursor, db

# Creating a Blueprint
customers_bp = Blueprint("customers", __name__)

@customers_bp.route('/customers', methods=['GET', 'POST'])
def customer_page():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        address = request.form['address']
        cursor.execute("INSERT INTO customers_demo (cust_name, cust_phone, cust_address) VALUES (%s, %s, %s)", (name, phone, address))
        db.commit()
    
    cursor.execute("SELECT * FROM customers_demo")
    customers = cursor.fetchall()
    return render_template("customer.html", customers=customers)


@customers_bp.route('/customer_list')
def show_reg_customers():
    cursor.execute("SELECT * FROM customers_demo")
    reg_customers = cursor.fetchall()
    return render_template("customer_list.html", reg_customers= reg_customers)