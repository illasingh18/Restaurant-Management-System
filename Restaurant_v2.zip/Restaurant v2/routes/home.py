from flask import Blueprint, render_template, request, redirect, url_for
from models import cursor, db

# Creating a Blueprint
home_bp = Blueprint("home", __name__)

@home_bp.route('/', methods=['GET', 'POST'])
def index():
    if request.method == "POST":
        option = request.form.get("option")  # Get selected dropdown value

        if option == "customers":
            return redirect(url_for('customers.customer_page'))
        elif option == "employees":
            return redirect(url_for('employees.employee_page'))
        elif option == "inventory":
            return redirect(url_for('inventory.inventory_page'))
    
    return render_template("home.html")

@home_bp.route('/home')
def home():
    return render_template("home.html")

@home_bp.route('/about')
def about_us():
    return render_template("about.html")

@home_bp.route('/contact')
def contact():
    return render_template("contact.html")
