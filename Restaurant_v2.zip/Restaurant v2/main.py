from __init__ import app

if __name__ == '__main__':
    app.run(debug=True)