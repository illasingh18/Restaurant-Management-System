# config.py

class Config:
    # Database Configuration
    DB_HOST = "localhost"
    DB_USER = "root"
    DB_PASSWORD = "admin123"
    DB_NAME = "restaurant"

    # Other configurations (if needed)
    DEBUG = True
